import os,sys,runpy,tarfile
from pathlib import Path
root=Path('/work');os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',JAX_PLATFORMS='cpu',JAX_ENABLE_X64='true',XLA_PYTHON_CLIENT_PREALLOCATE='false')
with tarfile.open(root/'source.tar') as archive:archive.extractall(root)
sys.path.insert(0,str(root/'source'));sys.argv=['triaxial_weaving_tl_guided_qualification','--output',str(root/'output'),'--steps','64','--checkpoint-every','64']
runpy.run_module('examples.triaxial_weaving_tl_guided_qualification',run_name='__main__')
