import os,sys,runpy,tarfile
from pathlib import Path
root=Path('/work');os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',JAX_PLATFORMS='cpu',JAX_ENABLE_X64='true',XLA_PYTHON_CLIENT_PREALLOCATE='false')
with tarfile.open(root/'source.tar') as archive:archive.extractall(root)
sys.path.insert(0,str(root/'source'));sys.argv=['prove_f7_tl_guide_diagonality','--output',str(root/'output')]
runpy.run_path(str(root/'source/tools/prove_f7_tl_guide_diagonality.py'),run_name='__main__')
