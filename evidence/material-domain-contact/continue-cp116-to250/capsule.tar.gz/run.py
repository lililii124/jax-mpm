from run_metal_tl_fresh import main
main()
