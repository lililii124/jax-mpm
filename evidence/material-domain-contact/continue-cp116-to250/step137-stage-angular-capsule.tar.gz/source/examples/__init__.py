"""Runnable mechanics examples."""
