import importlib, json, runpy, sys
sys.path.insert(0, '/work/source')
import mpm_jax
importlib.import_module('examples.metal_sphere_impact_fracture')
importlib.import_module('mpm_jax.metal_tl_midpoint')
importlib.import_module('mpm_jax.material_domain_contact')
importlib.import_module('mpm_jax.fragment_v6_discrete_work')
print(json.dumps({'startup_imports':'passed','mpm_jax':mpm_jax.__file__}), flush=True)
runpy.run_path('/work/source/tools/diagnose_tl_angular_step.py', run_name='__main__')
