import runpy
runpy.run_path('/work/source/run_metal_tl_fresh.py', run_name='__main__')
